<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use App\Notifikasi;

class Dashboard_controller extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('is_admin');
    }
    public function index()
    {	
    	// untuk notifikasi
        $data["notif"]      = Notifikasi::where("is_admin", "0")->orderBy('id', 'DESC')->get()->toArray();
        $data["total"]      = Notifikasi::where("is_admin", "0")->where("status", "0")->get()->toArray();

        return view('admin.dashboard', $data);
    }
}
