<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Tagihan;
use App\Pembayaran;
use App\Order;
use App\User;
use App\UserData;
use DB;
use App\UserStatus;
use App\Bank;
use App\Notifikasi;

class Tagihan_controller extends Controller
{
    protected $user;

    protected $userdata;
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware(function ($request, $next)
        {   
            $this->user = \Auth::user();
            $this->userdata = DB::table(UserData::TABLE)->join(UserStatus::TABLE,UserData::COL_ID,'=',UserStatus::COL_ID)->where(UserData::COL_ID,'=',$this->user->id)->first();
            
            return $next($request);
        });
        
        $this->model = new Order();
    }
    
    public function index()
    {
        if($this->user->tipe_akun!=User::TIPE_ADMIN){
            return redirect("dashboard");
        }
        // untuk notifikasi
        $data["notif"]      = Notifikasi::where("is_admin", "0")->orderBy('id', 'DESC')->get()->toArray();
        $data["total"]      = Notifikasi::where("is_admin", "0")->where("status", "0")->get()->toArray();

        $data["data"] = Tagihan::paginate(10);
        $data["bank"] = self::toList(Bank::all()->toArray(), 'id');
        $data["order"] = self::toList(Order::all()->toArray(), 'id');
        $data["user"] = self::toList(UserData::all()->toArray(), 'id');

        return view("admin.listtagihan", $data);
    }

    public function bayar(Request $request)
    {   
        $this->validate($request, [
            'metode' => 'required|numeric|min:1',
            'bank' => 'required|numeric|min:1',
            'id_order' => 'required|numeric|min:1'
        ]); 
        
        try{
            $order = Order::find($request->id_order);
            DB::beginTransaction();

            // untuk insert ke tagihan
            $tagihan = new Tagihan();
            $tagihan->id_order = $order->id;
            $tagihan->id_user = $order->id_murid;
            $tagihan->nominal = $order->total;
            $tagihan->metode = $request->metode;
            $tagihan->id_bank = $request->bank;
            $tagihan->keterangan = "Tagihan Order ".$order["kode_transaksi"]." Tanggal ".date("Y-m-d H:i:s");
            $tagihan->status = "0";
            $tagihan->create_date = date("Y-m-d H:i:s");
            $tagihan->expired_date = date('Y-m-d H:i:s', strtotime('+1 day', strtotime($tagihan->create_date)));
            $tagihan->updated_at = date("Y-m-d H:i:s");
            $tagihan->created_at = date("Y-m-d H:i:s");
            $tah = $tagihan->save();
            
            // update status di order setelah generate tagihan
            $data = ['status'=>'2'];

            $update = Order::where(Order::COL_ID, $request->id_order)->update($data);

            DB::commit();
        }catch (\Exception $e){
            $msg = [
                'error' => 'Pembuatan Tagihan Pembayaran Gagal Dibuat',
            ];
            
            return redirect()->back()->with($msg);
        }

        $msg = [
            'success' => 'Pembuatan Tagihan '.$order->kode_transaksi.' Berhasil',
        ];
        
        return redirect()->back()->with($msg);
    }


    public function konfirmasi(Request $request)
    {   
        $this->validate($request, [
            'bank' => 'required|numeric|min:1|max:4',
            'norek' => 'required|numeric|min:10',
            'nama' => 'required|min:3|max:255',
            'bukti' => 'required|min:10|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'id_tagihan' => 'min:1|required|numeric'
        ], [
            'bank.required' => "Bank harus diisi",
            'bank.numeric' => "Bank Tidak Valid",
            'bank.min' => "Bank Tidak Valid",
            'bank.max' => "Bank Tidak Valid",
            'norek.required' => "No Rekening harus diisi",
            'norek.numeric' => "No Rekening Tidak Valid",
            'norek.min' => "No Rekening Minimal 10 Karakter",
            'norek.max' => "No Rekening Maksimal 16 Karakter",
            'nama.required' => "Nama Rekening Harus diisi",
            'nama.min' => "Nama Rekening Minimal 3 Karakter",
            'nama.max' => "Nama Rekening Tidak Valid",
            'bukti.required' => "File Bukti Transfer Harus Diisi",
            'bukti.min' => "File Bukti Minimal 10 Kb",
            'bukti.min' => "File Bukti Maksimal 2 Mb",
            'id_tagihan.required' => "Tagihan Harus Ada",
            'id_tagihan.numeric' => "Tagihan Harus Valid",
            'id_tagihan.min' => "Tagihan Harus Valid"
        ]);

        $order = Tagihan::find($request->id_tagihan);
        try{
            DB::beginTransaction();
            $id = $this->user->id."-".time().'.'.request()->bukti->getClientOriginalExtension();
            
            // insert ke pembayaran
            $bayar = new Pembayaran();
            $bayar->id_tagihan = $order->id;
            $bayar->id_bank = $request->bank;
            $bayar->nama = $request->nama;
            $bayar->no_rekening = $request->norek;
            $bayar->keterangan = $request->keterangan;
            $bayar->status = '0';
            $bayar->nominal = $order->nominal;
            $bayar->filepath_bukti = $id;
            $bayar->created_at = date("Y-m-d H:i:s");
            $bayar->updated_at = date("Y-m-d H:i:s");
            $bayar->save();

            // update status konfirmasi tagihan
            $data = ['status'=>'1'];
            $update = Tagihan::where("id", $order->id)->update($data);
            
            // update status order di konfirmasi
            $data = ['status'=>'3'];
            $update = Order::where("id", $order->id_order)->update($data);
            
            // upload file
            request()->bukti->move('storage/uploads/transfer/', $id);
            
            DB::commit();
        }
        catch (\Exception $e){

            return redirect()->back()->with('error',"Error: ".$e->getMessage()." Gagal Upload Konfirmasi Transfer, Mohon Di Periksa Lagi")->withInput();
        }

        return redirect()->back()->with('success','Terimakasih Konfirmasi Bukti Transfer Berhasil ^_^');
    }
}
