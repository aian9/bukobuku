<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\KonfirmasiPembayaran;
use App\Order;
use App\OrderDate;
use App\RekeningSapaGuru;
use App\ReportOrder;
use App\Review;
use App\Transaksi;
use App\User;
use App\UserData;
use App\UserStatus;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Ramsey\Uuid\Uuid;

class OrderController extends Controller
{
    /**
     * @var User|null
     */
    protected $user;

    /**
     * @var UserData|UserStatus|null
     */
    protected $userdata;

    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware(function ($request, $next)
        {
            $this->user = \Auth::user();
            $this->userdata = DB::table(UserData::TABLE)->join(UserStatus::TABLE,UserData::COL_ID,'=',UserStatus::COL_ID)->where(UserData::COL_ID,'=',$this->user->id)->first();

            if ($this->userdata->email_activated == false)
                return redirect(route('verification.email'));

            return $next($request);
        });

        $this->middleware(function ($request, $next){
            if ($this->userdata->verified_profile == false)
                return redirect(route('user.dashboard.edit_profile'));

            return $next($request);
        });

        //KHUSUS GURU
        $this->middleware(function ($request, $next){
            if ($this->user->tipe_akun != User::TIPE_GURU)
                return redirect(route('user.dashboard.index'));

            return $next($request);
        })->only(['konfirmasi_guru_show','konfirmasi_guru_act']);

        //KHUSUS MURID
        $this->middleware(function ($request, $next){
            if ($this->user->tipe_akun != User::TIPE_MURID)
                return redirect(route('user.dashboard.index'));

            return $next($request);
        })->only(['invoice','konfirmasi','konfirmasiAct']);
    }

    public function invoice($id){
        if (!preg_match('/([0-9])+-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])-([0-9])+/',$id))
            abort('404');
        $orderDetails = preg_split('/-/',$id);
        $orderDate = $orderDetails[0].'-'.$orderDetails[1].'-'.$orderDetails[2];
        $order = Order::whereId($orderDetails[3])->whereBetween(Order::COL_CREATED_AT,[$orderDate.' 00:00:00',$orderDate.' 23:59:59'])->whereIdMurid($this->user->id)->firstOrFail();
        $guru = DB::table(User::TABLE)->join(UserData::TABLE,User::COL_ID,'=',UserData::COL_ID)
            ->where(User::COL_ID,'=',$order->id_guru)->first();
        $rekening = RekeningSapaGuru::all();

        $no_invoice = $order->id;
        
        return view('user.invoice.invoice')->with(compact('no_invoice','order','rekening','guru'));
    }

    public function konfirmasi($id){
        if (!preg_match('/([0-9])+-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])-([0-9])+/',$id))
            abort('404');
        $orderDetails = preg_split('/-/',$id);
        $orderDate = $orderDetails[0].'-'.$orderDetails[1].'-'.$orderDetails[2];
        $order = Order::whereId($orderDetails[3])->whereBetween(Order::COL_CREATED_AT,[$orderDate.' 00:00:00',$orderDate.' 23:59:59'])
            ->whereIdMurid($this->user->id)
            ->firstOrFail();

        if ($order->status != Order::STATUS_WAITING_PAYMENT)
            return redirect(route('user.dashboard.invoice',$order->no_invoice()))->withErrors(['Konfirmasi Pembayaran tidak dapat dilakukan!']);

        $no_invoice = $order->id;

        $konfirmasiPembayaran = KonfirmasiPembayaran::whereIdOrder($order->id)->count();

        return view('user.invoice.konfirmasi_pembayaran')->with(compact('order','no_invoice','konfirmasiPembayaran'));
    }

    public function konfirmasiAct($id,Request $request){
        if (!preg_match('/([0-9])+-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])-([0-9])+/',$id))
            abort('404');
        $orderDetails = preg_split('/-/',$id);
        $orderDate = $orderDetails[0].'-'.$orderDetails[1].'-'.$orderDetails[2];
        $order = Order::whereId($orderDetails[3])->whereBetween(Order::COL_CREATED_AT,[$orderDate.' 00:00:00',$orderDate.' 23:59:59'])
            ->whereIdMurid($this->user->id)
            ->firstOrFail();

        if ($order->status != Order::STATUS_WAITING_PAYMENT)
            return redirect(route('user.dashboard.invoice',$order->no_invoice()));

        $this->validate($request,[
            'nama' => ['required','string','max:60'],
            'bank' => ['required','string','max:50'],
            'norek' => ['required','string','max:60'],
            'nominal' => ['required','numeric'],
            'keterangan' => ['nullable','string'],
            'bukti' => ['required','image','mimes:jpeg,png,jpg','max:2048'],
        ],[

        ]);

        $konfirmasiPembayaran = new KonfirmasiPembayaran();
        $konfirmasiPembayaran->id_order = $order->id;
        $konfirmasiPembayaran->nama = $request->input('nama');
        $konfirmasiPembayaran->bank = $request->input('bank');
        $konfirmasiPembayaran->no_rekening = $request->input('norek');
        $konfirmasiPembayaran->nominal = $request->input('nominal');
        $konfirmasiPembayaran->keterangan = $request->input('keterangan');

        if ($request->hasFile('bukti'))
            $konfirmasiPembayaran->filepath_bukti = $request->file('bukti')->store(KonfirmasiPembayaran::BUKTI_PEMBAYARAN_DIR);

        try {
            if ($konfirmasiPembayaran->save())
                return redirect(route('user.dashboard.invoice', $order->no_invoice()))->with('success', 'Konfirmasi Pembayaran berhasil dilakukan! Silakan menunggu proses verifikasi!');
            return redirect()->back()->withErrors(['Gagal konfirmasi pembayaran'])->withInput();
        }
        catch (\Exception $exception){
            return redirect()->back()->withErrors(['Gagal konfirmasi pembayaran'])->withInput();
        }
    }

    public function order_list(){
        if ($this->user->tipe_akun == User::TIPE_MURID) {
            $order = Order::with(['order_dates','order_dates.kecamatan','order_dates.kecamatan.kota','order_dates.kecamatan.kota.provinsi','guru','murid','matpel','matpel.jenjang','review'])->where(Order::COL_ID_MURID, '=', $this->user->id)->orderBy(Order::COL_CREATED_AT, 'desc')->get();
            return view('user.order.order_list_murid')->with(compact('order'));
        }
        elseif ($this->user->tipe_akun == User::TIPE_GURU){
            $order = Order::with(['order_dates','order_dates.kecamatan','order_dates.kecamatan.kota','order_dates.kecamatan.kota.provinsi','guru','murid','matpel','matpel.jenjang','review'])
                ->whereNotIn(Order::COL_STATUS, [Order::STATUS_WAITING_PAYMENT, Order::STATUS_ABORTED, Order::STATUS_ABORTED_DONE, Order::STATUS_BALANCE_NOT_SUFFICIENT])
                ->where(Order::COL_ID_GURU, '=', $this->user->id)
                ->orderBy(Order::COL_CREATED_AT, 'desc')->get();
            return view('user.order.order_list_guru')->with(compact('order'));
        }
    }

    public function order_show(){

    }

    public function konfirmasi_guru_act(Request $request){
        $this->validate($request,[
            'id' => ['required','exists:'.Order::TABLE.",".Order::COL_ID],
            'action' => ['required','bool']
        ],[]);
        $order = Order::with(['order_dates'])->find($request->post('id'));

        //Cek STATUS
        if ($order->status != Order::STATUS_PAYMENT_VERIFIED)
            return redirect()->back()->withErrors(['Pembayaran tidak valid atau pesanan sudah dibatalkan']);

        try {

            if ($request->post('action') == 1) {
                //SETUJU
                $orderDateExist = DB::table(OrderDate::TABLE)->join(Order::TABLE, Order::COL_ID, '=', OrderDate::COL_ID_ORDER)
                    ->where(Order::COL_ID_GURU, '=', $order->id_guru)
                    ->where(Order::COL_ID, '<>', $order->id)
                    ->where(Order::COL_STATUS, '>=', Order::STATUS_PAYMENT_VERIFIED)
                    ->where(function ($query) use ($order) {
                        /** @var OrderDate $order_date */
                        foreach ($order->order_dates as $order_date) {
                            $query->orWhereBetween(OrderDate::COL_DATETIME, [$order_date->datetime, $order_date->datetime_end]);
                            $query->orWhereBetween(OrderDate::COL_DATETIME_END, [$order_date->datetime, $order_date->datetime_end]);
                            $query->orWhere(function ($query) use ($order_date) {
                                $query->where(OrderDate::COL_DATETIME, '<', $order_date->datetime);
                                $query->where(OrderDate::COL_DATETIME_END, '>', $order_date->datetime_end);
                            });
                        }
                    });

                if ($orderDateExist->count() > 0) {
                    //BATALKAN
                    $order->status = Order::STATUS_DATE_UNAVAILABLE;

                    //Kembalikan dana
                    $transaksi_return = new Transaksi();
                    $transaksi_return->id_user = $order->id_murid;
                    $transaksi_return->tipe = Transaksi::TIPE_IN_REJECTED;
                    $transaksi_return->nominal = $order->nominal_discounted();
                    $transaksi_return->keterangan = "Pengembalian dana pesanan dengan no invoice " . $order->no_invoice();
                    $transaksi_return->status = Transaksi::STATUS_OK;

                    if ($order->save() && $transaksi_return->save()) {
                        DB::commit();
                        return redirect()->back()->withErrors(['Membatalkan pesanan! Jadwal tidak tersedia!']);
                    }
                }

                $order->status = Order::STATUS_GURU_ACCEPTED;

                if($order->save()){
                    DB::commit();
                    return redirect()->back()->with('success','Pesanan diterima!');
                }
            } else {
                //TOLAK
                $order->status = Order::STATUS_GURU_REJECTED;

                //Kembalikan dana
                $transaksi_return = new Transaksi();
                $transaksi_return->id_user = $order->id_murid;
                $transaksi_return->tipe = Transaksi::TIPE_IN_REJECTED;
                $transaksi_return->nominal = $order->nominal_discounted();
                $transaksi_return->keterangan = "Pengembalian dana pesanan dengan no invoice " . $order->no_invoice();
                $transaksi_return->status = Transaksi::STATUS_OK;

                if ($order->save() && $transaksi_return->save()) {
                    DB::commit();
                    return redirect()->back()->with('success','Pesanan dibatalkan!');
                }
            }
        }
        catch (\Exception $exception) {
            return redirect()->back()->withErrors(['Error']);
        }
    }

    public function order_cancel(Request $request){
        $this->validate($request,[
            'id' => ['required','exists:'.Order::TABLE.','.Order::COL_ID]
        ]);
        $order = Order::findOrFail($request->post('id'));

        try {
            DB::beginTransaction();

            if ($order->status == Order::STATUS_PAYMENT_VERIFIED) {
                $transaksi_return = new Transaksi();
                $transaksi_return->id_user = $order->id_murid;
                $transaksi_return->tipe = Transaksi::TIPE_IN_ABORTED;
                $transaksi_return->nominal = $order->nominal_discounted();
                $transaksi_return->keterangan = "Pengembalian dana dari pembatalan pesanan dengan no invoice " . $order->no_invoice();
                $transaksi_return->status = Transaksi::STATUS_OK;

                $order->status = Order::STATUS_ABORTED_DONE;

                if ($transaksi_return->save() && $order->save()){
                    DB::commit();
                    return redirect(route('user.dashboard.order_list'))->with('success','Pesanan berhasil dibatalkan!');
                }
                return redirect(route('user.dashboard.order_list'))->withErrors(['Terjadi masalah. Pesanan tidak dapat dibatalkan!']);
            } elseif ($order->status == Order::STATUS_WAITING_PAYMENT || $order->status == Order::STATUS_BALANCE_NOT_SUFFICIENT) {
                $order->status = Order::STATUS_ABORTED;
                if ($order->save())
                {
                    DB::commit();
                    return redirect(route('user.dashboard.order_list'))->with('success','Pesanan berhasil dibatalkan!');
                }
                return redirect(route('user.dashboard.order_list'))->withErrors(['Terjadi masalah. Pesanan tidak dapat dibatalkan!']);
            }
            return redirect(route('user.dashboard.order_list'))->withErrors(['Pesanan tidak dapat dibatalkan!']);
        }
        catch (\Exception $exception){
            return redirect(route('user.dashboard.order_list'))->withErrors(['Terjadi masalah. Pesanan tidak dapat dibatalkan!']);
        }
    }

    public function order_cancel_get(){
        return redirect(route('user.dashboard.order_list'));
    }

    public function order_done(Request $request){
        $this->validate($request,[
            'id' => 'exists:'.Order::TABLE.','.Order::COL_ID,
        ]);
        $order = Order::find($request->post('id'));
        if (empty($order))
            return redirect(route('user.dashboard.order_list'));

        if ($order->status != Order::STATUS_GURU_ACCEPTED)
            return redirect(route('user.dashboard.order_list'))->withErrors(['Status Order Tidak Valid!']);

        try{
            DB::beginTransaction();

            $transaksi = new Transaksi();
            $transaksi->id_user = $order->id_guru;
            $transaksi->tipe = Transaksi::TIPE_IN_GURU_HONOR;
            $transaksi->nominal = $order->nominal;
            $transaksi->keterangan = "Gaji dari pesanan dengan nomor invoice ".$order->no_invoice();
            $transaksi->status = Transaksi::STATUS_OK;

            $order->status = Order::STATUS_DONE;

            if ($transaksi->save() && $order->save()) {
                DB::commit();
                return redirect(route('user.dashboard.order_list'))->with('success','Pesanan selesai');
            }

            return redirect(route('user.dashboard.order_list'))->withErrors(['Error']);
        }
        catch (\Exception $exception){
            return redirect(route('user.dashboard.order_list'))->withErrors(['Error']);
        }
    }

    public function order_done_get(){
        return redirect(route('user.dashboard.order_list'));
    }

    public function order_review(Request $request){
        $this->validate($request,[
            'id' => 'exists:'.Order::TABLE.','.Order::COL_ID,
            'review' => ['nullable','string'],
            'rating' => ['required','numeric','min:1','max:5'],
        ]);
        $review = Review::where(Review::COL_ID_ORDER,'=',$request->post('id'));

        if ($review->count() > 0)
            return redirect(route('user.dashboard.order_list'))->withErrors(['Review sudah ada!']);

        $review = new Review();
        $review->id_order = $request->post('id');
        $review->rating = $request->post('rating');
        $review->review = $request->post('review');
        if ($review->save())
            return redirect(route('user.dashboard.order_list'))->with('success','Review berhasil dibuat!');

        return redirect(route('user.dashboard.order_list'))->withErrors(['Gagal membuat review!']);
    }

    public function order_review_get(){
        return redirect(route('user.dashboard.order_list'));
    }

    public function order_report(Request $request){
        $this->validate($request,[
            'id' => ['required', 'exists:'.Order::TABLE.','.Order::COL_ID],
            'subject' => ['required','string'],
            'description' => ['required','string'],
        ]);

        $order = Order::find($request->post('id'));

        if ($order->status < Order::STATUS_WAITING_PAYMENT || $order->status >= Order::STATUS_DONE)
            return redirect(route('user.dashboard.order_list'))->withErrors(['Laporan tidak dapat dibuat!']);

        $report = new ReportOrder();
        $report->id_order = $request->post('id');
        $report->subject = $request->post('subject');
        $report->description = $request->post('description');
        $report->status = ReportOrder::STATUS_CREATED;
        if ($report->save())
            return redirect(route('user.dashboard.order_list'))->with('success','Laporan berhasil dikirim!');
        return redirect(route('user.dashboard.order_list'))->withErrors(['Gagal membuat laporan!']);
    }

    public function order_report_get(){
        return redirect(route('user.dashboard.order_list'));
    }
}
