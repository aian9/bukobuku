<?php

namespace App\Http\Controllers\User;

use App\JadwalGuru;
use App\Kecamatan;
use App\KotaKab;
use App\MataPelajaranGuru;
use App\Order;
use App\OrderDate;
use App\Provinsi;
use App\Review;
use App\User;
use App\UserData;
use App\UserStatus;
use DateInterval;
use DateTime;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class GuruController extends Controller
{
    /**
     * @var User|null
     */
    protected $user;

    /**
     * @var UserData|UserStatus|null
     */
    protected $userdata;
    /**
     * DashboardUser constructor.
     */

    /**
     * GuruController constructor.
     */
    public function __construct()
    {
        $this->middleware('auth')->only(['pesan','pesanAct']);
        $this->middleware(function ($request, $next)
        {
            $this->user = \Auth::user();
            $this->userdata = DB::table(UserData::TABLE)->join(UserStatus::TABLE,UserData::COL_ID,'=',UserStatus::COL_ID)->where(UserData::COL_ID,'=',$this->user->id)->first();

            if ($this->userdata->email_activated == false)
                return redirect(route('verification.email'));

            return $next($request);
        })->only(['pesan','pesanAct']);

        $this->middleware(function ($request, $next){
            if ($this->userdata->verified_profile == false)
                return redirect(route('user.dashboard.edit_profile'));

            return $next($request);
        })->only(['pesan','pesanAct']);
    }

    public function index(){
        /** @var User[] $data */
        $data = DB::table(User::TABLE)->join(UserData::TABLE,User::COL_ID,'=',UserData::COL_ID)
            ->join(UserStatus::TABLE,User::COL_ID,'=',UserStatus::COL_ID)
            ->where(User::COL_TIPE_AKUN,'=',User::TIPE_GURU)
            ->where([[UserStatus::COL_ACCEPTED_TEACHER,'=',true],[UserStatus::COL_VERIFIED_PROFILE,'=',true],[UserStatus::COL_EMAIL_ACTIVATED,'=',true],[UserStatus::COL_SUSPENDED_ACCOUNT,'=',false]])
            ->get();

        return view('user.index_guru')->with(compact('data'));
    }

    public function show($username){
        /** @var User[] $data */
        $data = DB::table(User::TABLE)->join(UserData::TABLE,User::COL_ID,'=',UserData::COL_ID)
            ->join(UserStatus::TABLE,User::COL_ID,'=',UserStatus::COL_ID)
            ->where(User::COL_TIPE_AKUN,'=',User::TIPE_GURU)
            ->where([[User::COL_USERNAME,'=',$username]])
            ->first();

        if (empty($data))
            abort(404);

        return view('user.show_guru')->with(compact('data'));
    }

    public function pesan($username){
        $guru = DB::table(User::TABLE)->join(UserData::TABLE,User::COL_ID,'=',UserData::COL_ID)
            ->where(User::COL_USERNAME,'=',$username)->first();

        if (empty($guru))
            abort('404');

        $rating = DB::table(Review::TABLE)->join(OrderDate::TABLE,Review::COL_ID_ORDER,'=',OrderDate::COL_ID)
            ->join(Order::TABLE,OrderDate::COL_ID_ORDER,'=',Order::COL_ID)
            ->where(Order::COL_ID_GURU,'=',$guru->id)
            ->get([Review::COL_RATING]);

        $nilai = 0;
        foreach ($rating as $item)
            $nilai+=$item->rating;
        $rating = count($rating)>0?$nilai/count($rating):0;

        $mpg = MataPelajaranGuru::with('matpel')->whereIdUser($guru->id)->whereStatus(MataPelajaranGuru::STATUS_VERIFIED)->get();
        return view('user.pesan_guru')->with(compact('guru','mpg','rating'));
    }

    public function pesanAct(Request $request){
        $this->validate($request,[
            'matpel' => ['required','exists:'.MataPelajaranGuru::TABLE.','.MataPelajaranGuru::COL_ID],
            'jmlPertemuan' => ['required','numeric','min:5','max:15'],
            'durasiPertemuan' => ['required','numeric','min:1','max:5'],
            'tglOrder.*' => ['required','date'],
            'jamOrder.*' => ['required','numeric','min:7','max:20'],
            'alamat' => 'required',
            'provinsi' => ['required','exists:'.Provinsi::TABLE.','.Provinsi::COL_ID],
            'kota' => ['required','exists:'.KotaKab::TABLE.','.KotaKab::COL_ID],
            'kecamatan' => ['required','exists:'.Kecamatan::TABLE.','.Kecamatan::COL_ID],
        ],[

        ]);

        $errorMsg = ['Gagal membuat pesanan!'];
        $durasi = [
            1 => 1,
            2 => 1.5,
            3 => 2,
            4 => 2.5,
            5 => 3,
        ];
        $durasiPertemuan = $durasi[$request->input('durasiPertemuan')];

        $mataPelajaranGuru = MataPelajaranGuru::find($request->input('matpel'));
        if($mataPelajaranGuru->status==MataPelajaranGuru::STATUS_UNVERIFIED)
            return redirect()->back()->withErrors(['Mata pelajaran tidak valid'])->withInput();

        $order = new Order();
        $order->id_guru = $mataPelajaranGuru->id_user;
        $order->id_murid = $this->user->id;
        $order->id_matpel = $mataPelajaranGuru->id_matpel;
        $order->nominal = $request->input('jmlPertemuan') * $mataPelajaranGuru->tarif * $durasiPertemuan;

        try{
            $success = true;
            DB::beginTransaction();

            if(!$order->save())
                $success = false;

            for ($i = 0; $i<$request->input('jmlPertemuan'); $i++){
                $datetime = DateTime::createFromFormat('m/d/Y H',$request->input('tglOrder')[$i].' '.$request->input('jamOrder')[$i]);
                $datetimeFormatted = $datetime->format('Y-m-d H:i:s');
                $datetimeTill = DateTime::createFromFormat('m/d/Y H',$request->input('tglOrder')[$i].' '.$request->input('jamOrder')[$i])
                    ->add(new DateInterval('PT'.floor($durasiPertemuan).'H'.(($durasiPertemuan-floor($durasiPertemuan))*60).'M'))
                    ->sub(new DateInterval('PT1S'));
                $datetimeTillFormatted= $datetimeTill->format('Y-m-d H:i:s');

                $orderDateInRange = JadwalGuru::where(JadwalGuru::COL_ID_USER,'=',$order->id_guru)
                    ->where(JadwalGuru::COL_DAY,'=',$datetime->format('w'))
                    ->where(function ($query) use($datetime,$durasiPertemuan){
                        $query->where(JadwalGuru::COL_TIME,'=',$datetime->format('G'));
                        for ($i=1;$i<ceil($durasiPertemuan);$i++){
                            $query->orWhere(JadwalGuru::COL_TIME,'=',((int)$datetime->format('G'))+$i);
                        }
                    });

                if ($orderDateInRange->count()<ceil($durasiPertemuan)){
                    $success = false;
                    $errorMsg['tglOrder'.$i][] = 'Tanggal dan waktu tidak tersedia';
                }

                $orderDateExist = DB::table(OrderDate::TABLE)->join(Order::TABLE,Order::COL_ID,'=',OrderDate::COL_ID_ORDER)
                    ->where(Order::COL_ID_GURU,'=',$order->id_guru)
                    ->where(Order::COL_STATUS,'>=',Order::STATUS_PAYMENT_VERIFIED)
                    ->where(function ($query) use($datetimeFormatted,$datetimeTillFormatted){
                        $query->whereBetween(OrderDate::COL_DATETIME,[$datetimeFormatted,$datetimeTillFormatted]);
                        $query->orWhereBetween(OrderDate::COL_DATETIME_END,[$datetimeFormatted,$datetimeTillFormatted]);
                        $query->orWhere(function ($query) use($datetimeFormatted,$datetimeTillFormatted){
                            $query->where(OrderDate::COL_DATETIME,'<',$datetimeFormatted);
                            $query->where(OrderDate::COL_DATETIME_END,'>',$datetimeTillFormatted);
                        });
                    });

                if ($orderDateExist->count()>0) {
                    $success = false;
                    $errorMsg['tglOrder'.$i][] = 'Tanggal dan waktu tidak tersedia';
                }

                $datetimeTill = $datetimeTill->add(new DateInterval('PT1S'));
                $datetimeTillFormatted = $datetimeTill->format('Y-m-d H:i:s');

                $orderDate = new OrderDate();
                $orderDate->id_order = $order->id;
                $orderDate->datetime = $datetimeFormatted;
                $orderDate->datetime_end = $datetimeTillFormatted;
                $orderDate->durasi = $durasiPertemuan;
                $orderDate->alamat_jalan = $request->input('alamat');
                $orderDate->alamat_kecamatan = $request->input('kecamatan');
                if (!$orderDate->save())
                    $success = false;
            }

            if ($success) {
                DB::commit();
                return redirect(route('user.dashboard.invoice',$order->no_invoice()))->with('success','Pesanan Berhasil Dibuat!');
            }
            DB::rollBack();
            return redirect()->back()->withErrors($errorMsg)->withInput();
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()->withErrors(['Gagal membuat pesanan'])->withInput();
        }
    }
}
